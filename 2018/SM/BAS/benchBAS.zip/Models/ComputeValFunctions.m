Vind=double(Safe2D.contains(L\[kron(zrep1,ones(1,nz2));kron(ones(1,nz1),zrep2)])');
disp('composed indicator function, ready for iterations')

% surf(zrep1,zrep2,reshape(Vind,nz2,nz1),'EdgeColor','none'),
% xlim([min(zrep1),max(zrep1)])
% ylim([min(zrep2),max(zrep2)])
% hold on
% plot((L*Safe2D)*Polyhedron(3),'Alpha',.1); hold on
% xlim([min(zrep1),max(zrep1)])
% ylim([min(zrep2),max(zrep2)])
% 
% figure, surf(zrep1,zrep2,reshape(Vind,nz2,nz1)),
% title('safe set'); drawnow;
find(Vind~=0);
Vsq=zeros(nz2,nz1);
Vsq(:)=Vind;
V_aux=zeros(nz1*nz2,nu);
%figure,
Policy=zeros(nz2,nz1);%figure ; hold on;
for k=N:-1:1
    
    Vsq(:)=Pz2*Vsq*Pz1';
    V_aux(:) =  Pdet*Vsq(:);
    disp(k)
    
    [Vsq(:),Policy(:)] =  max(V_aux,[],2);
    %savefile = ['Policy',num2str(k),'.mat'];
    
 %   var_save=['''Policy''',',','''Vsq'''];
%    eval([' save( savefile ', ',',var_save,')'])
   % mesh(zrep1,zrep2,Vsq);drawnow;%pause
end

F_z=scatteredInterpolant([kron(zrep1,ones(1,nz2));kron(ones(1,nz1),zrep2)]',Vsq(:),'nearest');
x1=(Bound_L(1):.05:Bound_H(1));
x2=(Bound_L(2):.05:Bound_H(2));
[X1,X2]=meshgrid(x1,x2);
%figure, mesh(X1,X2,F_z(X1,X2))
%title('safety probabilities')
%figdir = strcat('ValFuc',strcat(num2str(Concreteorder), num2str(Abstractorder)));
%saveFigs_shortcuts
p = max(max(F_z(X1,X2)));
