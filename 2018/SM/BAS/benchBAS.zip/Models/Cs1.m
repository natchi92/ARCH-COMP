%---------------------------------------------------------
% Deterministic Model 
% x_da[k+1] = Ax_da[k] + Bu[k] + F_dad[k] + Q_da
% y_da[k]   = diag([1 1 0 0])x_da[k]
% x_d = [T_z1 T_z1 T_rw,rad1 T_rw,rad2]^T
% u   = T_sa
% d   = [CO2_1 CO2_2]^T
%---------------------------------------------------------
clc; clear; close all
addContainingDirAndSubDir;
%---------------------------------------------------------
% Load parameters needed to build models
%---------------------------------------------------------
getParameters;
Ts = 15;                 % Sample time (minutes)
T  = 4*24*3;
%---------------------------------------------------------
% Creation of Models 
%---------------------------------------------------------
%% Steady state values
Tswb  = 75;     %[deg C]
Tsp   = 20;     %[deg C]
Twss  = 20;     %[deg C]
Trwrss= 35;     %[deg C]
Pout1 = .8;    %[kW]
Pout2 = .6;    %[kW]
m     = 5/60;  %[m^3/min]

P = diag([1 1]);% 30 30]);
Ac = zeros(2,2);%,4);
Ac(1,1) = -(1/(Zone1.Rn*Zone1.Cz))-((Pout1*Radiator.p8)/(Zone1.Cz)) - ((m*Materials.air.Cpa)/(Zone1.Cz));
Ac(2,2) = -(1/(Zone2.Rn*Zone2.Cz))-(Pout2*Radiator.p8)/(Zone2.Cz) - (m*Materials.air.Cpa)/(Zone2.Cz);

Bc = inv(P)*[(m*Materials.air.Cpa)/(Zone1.Cz) (m*Materials.air.Cpa)/(Zone2.Cz)]';% 0 0]';
d0 =(Twss/(Zone1.Rn*Zone1.Cz))+ (Radiator.p9)/(Zone1.Cz) + (Pout1*Radiator.p8)*Trwrss/(Zone1.Cz) ;
g0 =((Twss-1)/(Zone2.Rn*Zone2.Cz))+ (Radiator.p9)/(Zone1.Cz)+ (Pout2*Radiator.p8)*Trwrss/(Zone2.Cz);

x1_bar=(-Bc(1,1)-d0)/Ac(1,1);
x2_bar=(-Bc(2,1)-g0)/Ac(2,2);

u1_bar = (-Ac(1,1)*x1_bar-d0);
u2_bar = (-Ac(2,2)*x1_bar-g0);

x1b= x1_bar*(Ac(1,1)-1);
x2b= x1_bar.*(Ac(2,2)-1);
d = d0 ;
g = g0;

Fc = [d g ]';
Fc = inv(P)*Fc;

Cc = diag([1 1]);

Sigma =diag([Zone1.Tz.sigma*sqrt(Ts) Zone2.Tz.sigma*sqrt(Ts)]);
Z1m=createModel_v2;
Z1f = Z1m;
Z1m=InitialiseModel(Z1m,'l','s',Ac,Bc,Cc,Fc,[],[],Ts,Sigma);
Z1m=createSymbModel(Z1m);

Daterange = 1:T;
tsa = 15;
Tsa = ones(T,1);
Tsa(32:48)=tsa.*ones(17,1);
Tsa(52:72)=tsa.*ones(21,1);
Tsa(32+96:48+96)=tsa.*ones(17,1);
Tsa(52+96:72+96)=tsa.*ones(21,1);
Tsa(32+96*2:48+96*2)=tsa.*ones(17,1);
Tsa(52+96*2:72+96*2)=tsa.*ones(21,1);
Tsa(32+96*3:48+96*3)=tsa.*ones(17,1);
Tsa(52+96*3:72+96*3)=tsa.*ones(21,1);

D   = ones(T,1);    
   
dWz        = sqrt(Z1m.dt).*randn(T,size(Z1m.A,2));         % Brownian increments
Z1m.dW     = dWz;

%---------------------------------------------------------
% FAUST
%---------------------------------------------------------

Z1f=InitialiseModel(Z1f,'l','d',Ac,Bc,Cc,[],[],[],Ts,Sigma);
Z1f=createSymbModel(Z1f);
KernelFunction = Z1f.tr;
alpha(1,1) = Z1m.A(1,1);
alpha(2,2) = Z1m.A(2,2);
sigma = Z1m.sigma;
%---------------------------------------------------------
% Define Horizon
%-----------------------------------------------------------------------------
% Define allowable abstraction error
%---------------------------------------------------------
epsilon = 160;

%---------------------------------------
N      = 6;tic;
%---------------------------------------------------------
% Define Safe & Input Set
%---------------------------------------------------------
SafeSet = [ 19.5 20.5; 19.5 20.5 ]; 
InputSet = [18 19];
%-------------------------------------------------------
% 2. Perform gridding 
%along each dimension and check if
% synthesis can be performed
%--------------------------------------------------------
[X,U,E] = Uniform_grid_Contr(2*epsilon,KernelFunction,N,SafeSet,InputSet);
E=0.5*0.9633*E/510;

disp(['The abtraction consists of ',num2str(size(X,1)),' representative points of the system.']);
disp(['The abtraction consists of ',num2str(size(U,1)),' representative points of the input.']);E=0.5*E
Tp=MCapprox_Contr(KernelFunction,X,U);
[V,OptimPol] = StandardProbSafety_Contr(N,Tp); toc
Solution = V;
dim = 2;
FAUST_plot;
save('Cs1.mat','E','N','Solution','OptimPol','Tp','X','U');