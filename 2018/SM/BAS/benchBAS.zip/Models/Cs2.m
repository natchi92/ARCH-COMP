% Generalizing of Sofies code to turn into a toolbox
% Requires : Two Models -> Concrete ans Abstract models
%          : Bisimulation (\eps,\delta) bounds
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
warning('off','all')
warning
clear; clc; %close all
addContainingDirAndSubDir

%---------------------------------------------------------
% Model definition
% Concrete model: Model Order 7
% Abstract model: Model Order 1
%---------------------------------------------------------
%---------------------------------------------------------
% Concrete Model definition
%---------------------------------------------------------
yss           = 20/30;
dt            = 15*60;
Concreteorder = 7;

%% Get model
CaseStudy2_Mc;

sysd=Z1m;


%%%%%%%%%%%%%%%%%%%%% Steady State %%%%%%%%%%%%%%%%%%%%%%%%%
A = Z1m.A;
B = Z1m.B(:,1);
F = Z1m.F(:,1:end-1);
C = sysd.C;
dm=[9 15 500 500 35 35];
X =repmat(yss,size(A,2),1);
uss7 = (X - A*X - F*dm')'*pinv(B)';

xss = A*X+B*uss7+F*dm' + Z1m.F(:,end);
yss7 = C*xss;

%%%%%%%%%%%%%%%%%%%%%%%%% Transient Node %%%%%%%%%%%%%%%%%%%%%%%%%
Sigma =diag([1/30,1/30,100,100,5/30,5/30]);

Ahat7  = A;
Bhat7  = B;
Chat7  = C;

Fhat7  = F*(sqrtm(Sigma));
sysdfull  = ss(Ahat7,[Bhat7 Fhat7],Chat7,[],dt);

disp('Concrete Model');

%---------------------------------------------------------
% Abstract Model definition
%---------------------------------------------------------
Abstractorder = 1;
CaseStudy2_Mc1;

%%%%%%%%%%%%%%%%%%%%% Steady State %%%%%%%%%%%%%%%%%%%%%%%%%
A = Z1m.A;
B = Z1m.B;
F = Z1m.F(:,1:end-1);
C = Z1m.C;
dm1=[9 500 35];

X1 =repmat(yss,size(A,2),1);
uss1 = (X1 - A*X1 - F*dm1')'*pinv(B)';
xss1 = A*X1+B*uss1+F*dm1' + Z1m.F(:,end);
yss1 = C*xss1;

%%%%%%%%%%%%%%%%%%%%%%%%% Transient %%%%%%%%%%%%%%%%%%%%%%%%%
Ahat1  = A;
Bhat1  = B;
Chat1  = C;
Sigma  = diag([1/30,100,5/30]);
Fhat1  = F*(sqrtm(Sigma));
sysd1  = ss(Ahat1,[Bhat1 Fhat1],Chat1,[],dt);
disp('Abstract Model');

%---------------------------------------------------------
% Obtain initial estimates for K and M matrix
% using infinite-horizon LQ stochastic optimal control
% by computing the unique stabilizing solution X
%---------------------------------------------------------

[Ml,~, K,report]=dare(sysdfull.a,sysdfull.b(:,1), sysdfull.c'*sysdfull.c, 0.0001);

[Ml,~, K1]=dare(sysdfull.A,sysdfull.B(:,1),sysdfull.C'*sysdfull.C+ .5*eye(Concreteorder),0.9)  ;


%----------------------m-----------------------------------
% Obtain bisimulation relations and select optimal pair
%---------------------------------------------------------
c_1         =1/30;

tic;
[Q,R,P,M,K,epsNew,deltarangeNew]=Compute_App_Bisim(sysdfull,sysd1, Ml,K1,60,c_1);
NumPair = 1;
Epsilon = epsNew(NumPair)
del     = 1-deltarangeNew(NumPair)
%---------------------------------------------------------
% Define Safe Set (2D for now) and input bounds
% Assuming 1 control input to be refined
%---------------------------------------------------------

% Select number of control inputs
sysdred = sysd1;
B = sysdred.B(:,1)*R^-1;
A = sysdred.A;
Bw= sysdred.B(:,2:end);
C = sysdred.C;

maxTemp  = 0.5;          
minTemp  = -0.5;
if Epsilon > maxTemp
    disp('Cant compute')
    return
end
[Safe2D, Safe_err] = get2DSafeSet(maxTemp, minTemp, Epsilon);
Safe_Range = 0.5;
% Time dependend bound on input
u_com       = c_1;                 % u^2 <= c_1,L,Safe2D
umax        = 1;
umin        = 0;
%pred_heating= [minTemp;minTemp;minTemp;minTemp;minTemp;minTemp];
U_Lt        = [-0.5;-0.5;- 0.5;- 0.5;-0.5;-0.5;-0.5;-0.5;- 0.5;- 0.5;-0.5;-0.5];% -pred_heating;
U_Ht        = [0.5;0.5; 0.5; 0.5;0.5; 0.5;0.5;0.5; 0.5; 0.5;0.5; 0.5];%1-pred_heating;
u_d         = sqrt(K/M*K')*Epsilon; %  (comes from K(x-x), sqrt(K/MK')*eps) % BE AVAILABLE TO DO TUNING
u_d=0;
if u_d>1
    disp('  u_d >1')
    disp(u_d)
    % pause
end
% correct with R; and with u_d
U_Lt_cor=min([R*( U_Lt+u_d);-u_com*ones(size(U_Ht))]);% TO be fixed
U_Ht_cor=max([R*( U_Ht-u_d);u_com*ones(size(U_Ht))]);

disp('Safe sets defined');


% Split for controller design
%---------------------------------------------------------
% Define Horizon
%---------------------------------------------------------
N      = 6;
gamma  = N*del;
disp('Property being solved');
disp(['P>=p + ' num2str(gamma) '(G^' num2str(N) '|y| < ' num2str(Safe_Range) '-' num2str(Epsilon) ')']);
%Faust_mini_OR
L   = NoiseDecoupling(Bw);
A_p = L*A/L;
B_p = L*B;
disp('Noise Decoupled');

%---------------------------------------------------------
% Synthesize and refine controller
% 1. State space transformation and obtaining boundaries
%---------------------------------------------------------
%---------------------------------------------------------
Safe_L = L*Safe2D; % 2D safeset with decoupled noise
coef1  = 0.1;        % Coeff|icients to shift boundary of safe set
coef2  = .13;
A_L    = min(Safe_err.V);
A_H    = max(Safe_err.V); 

Linv    = inv(L);
Bound_L = -abs([coef1*A_L/Linv; coef2*A_L/Linv]);
Bound_H = abs([coef1*A_H/Linv; coef2*A_H/Linv]);

Hz1     = (abs(A_p(1,1))+abs(A_p(1,1)))*2/(sqrt(2*pi));
Hz2     = (abs(A_p(1,1))+abs(A_p(1,1)))*2/(sqrt(2*pi));
Hup     = (abs(B_p(1,1))+abs(B_p(1,1)))*2/(sqrt(2*pi));

Error   = 0.15;        % Required minimal error in gridding


% Set up partition diameters - To be tuned
delta_up = Error/(2*N*Hup);
delta_z1 = Error/(2*N*Hz1);
delta_z2 = Error/(2*N*Hz2);
nu       = 20;
Error    = N*(Hz1*delta_z1 + Hz2*delta_z2);% (simulation error, not bisimulation)

%---------------------------------------------------------
% 2. Perform gridding along each dimension and check if
% synthesis can be performed
%---------------------------------------------------------

% Gridding along first dimension (Control input)
disp('nz1 along Dim 1 (control input)');
[nz1, z1, delta_z1, zrep1] = GriddingDimension(Bound_H(1), Bound_L(1), delta_z1);
disp(['nz1 = ' num2str(nz1)]);

% Gridding along second dimension (Output)
disp('nz2 along Dim 2 (output)');
[nz2, z2, delta_z2, zrep2] = GriddingDimension(Bound_H(2), Bound_L(2), delta_z2);
disp(['nz2 = ' num2str(nz2)]);


if nz2*nz1>10^7
    disp(' Computationally not feasible to perform synthesis!');
    disp(['nz2*nz1 =' num2str(nz2*nz1)]);
    
    disp('nz2*nz1>10^7.5')
    feasible = 0;
    return;
else
    disp(' Computationally feasible will proceed with synthesis');
    disp(['nz2*nz1 =' num2str(nz2*nz1)]);
    feasible = 1;
    
   % pause
end

if feasible
    % Discretize Input Space
    
    [delta_up, urep] = DiscretizeInput(U_Lt_cor, U_Ht_cor, c_1 ,nu);
    %---------------------------------------------------------
    % 2. Obtain Stochastic Transitions
    %---------------------------------------------------------
    
    % Obtain stochastic transitions along first dimension
    Pz1 = obtainStochasticTransitions(nz1,zrep1,delta_z1);
    
    % Obtain stochastic transitions along second dimension
    Pz2 = obtainStochasticTransitions(nz2,zrep2,delta_z2);
    
    %---------------------------------------------------------
    % 3. Deterministic Transitions  & convert to sparse matrix
    %---------------------------------------------------------
    
    [Pdet,z]= Det_trans(A_p,B_p,zrep1,zrep2,urep, L,Safe2D);
    length(z)
    disp('Sparse ready')
    %---------------------------------------------------------
    % 4. Compute Value Functions and obtain policies
    %---------------------------------------------------------
    
    ComputeValFunctions;
    disp('done with iterations, Got a value function')
    disp('Property solved for abstract model ');
    disp(['P>= ' num2str(p-Error) '(G^' num2str(N) '|y| < ' num2str(Safe_Range) ')']);
 
    disp(['P>= ' num2str(p-Error-gamma) '(G^' num2str(N) '|y| < ' num2str(Safe_Range-Epsilon) ')']);
    toc
    save('Cs2.mat','p','Error','gamma','N');
end

