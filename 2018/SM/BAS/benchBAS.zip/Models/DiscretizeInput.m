function     [delta_up, urep] = DiscretizeInput(U_Lt_cor, U_Ht_cor, c_1, nu)

U_L     = min(U_Lt_cor);
U_H     = max(U_Ht_cor);
u       = linspace(U_L,U_H,nu+1); % boundaries of the partition sets for input
delta_up = (U_H-U_L)/nu; % diameter for input

if delta_up>.2   % To be confirmed
    disp('delta_up>.2')
    pause
end
urep = u(1:nu) + delta_up/2; % representative points for input


end

