function [nz, z, delta_z, zrep] = GriddingDimension(Bound_H, Bound_L, delta_z)

nz      = ceil((Bound_H - Bound_L)/delta_z);
z       = linspace(Bound_L,Bound_H,nz+1);       % boundaries of the partition sets 
delta_z = (Bound_H-Bound_L)/nz ;                % diameter 
zrep    = z(1:nz) + delta_z/2;                  % representative points 

end
