function [L, Linv] = NoiseDecoupling(Bw)

Zigma = Bw*Bw';  % Standard Deviation of process noise

L    = sqrtm(inv(Zigma)); % Sqrtm - principal sqrt of input matrix

%det(Zigma)

end
