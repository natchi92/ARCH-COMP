function Bws = ZeroPadBws(Bws, Bw)

[a,a1] = size(Bws);
[~,b] = size(Bw);

Bws =[Bws(:,1) 0 Bws(:,2) 0 Bws(:,end) 0];% zeros(a,b-a1)];
end
