classdef createModel_v2
    % Class to build models
    
    properties
        dim;          % Model dimension
        dim_u;        % Input dimension
        dim_d;        % Noise dimension
        Type;         % Linear - 'l' / Bilinear - 'b'
        Noise;        % Deterministic -'d' / Stochastic - 's'
        A;            % A-matrix
        B;
        C;
        F;
        N;
        tr;           % transitions function
        dt;           % Discrete time step - Applying first order Euler (no weiner process)
        sigma;
        dW;
    end
    
    methods
        %%%%%%%%%%% Initialisation of model %%%%%%%%%%
        function obj = InitialiseModel(obj,Type,Noise,A,B,C,F,N,tr,dt,sigma)
            
            obj.Type   = Type;
            obj.Noise  = Noise;
            obj.A      = A;
            obj.B      = B;
            obj.C      = C;
            obj.F      = F;
            obj.N      = N;
            obj.tr     = tr;
            obj.dt     = dt;
            
            if obj.Noise == 'd'
                obj.sigma  = [];
                obj.dW     = [];
            else
                obj.sigma = sigma;
                obj.dW    = [];       % Brownian increments
            end
            
            
            obj.dim    = size(A,2);
            obj.dim_u  = size(B,2);
            obj.dim_d  = size(F,2);
            
            %%% Discretize matrices
            obj.A = eye(size(A)) + obj.dt.*obj.A;
            obj.B = obj.dt.*obj.B;
            obj.F = obj.dt.*obj.F;
            if obj.Type ~= 'l'
                obj.N = obj.dt.*obj.N;
            end
            
        end
        
        %%%%%%%%%%% Creation of symbolic model %%%%%%%%%%
        function sys = createSymbModel(obj)
            sys = obj;
            
            x='';xbar='';
            
            for i=1:obj.dim
                eval(['syms',' ','x',num2str(i),' ','real']);
                eval(['syms',' ','x',num2str(i),'bar ','real']);
                x=[x,'x',num2str(i),' '];
                xbar=[xbar,'x',num2str(i),'bar '];
            end
            if x(end)==' '
                x=x(1:end-1);
            end
            
            if xbar(end)==' '
                xbar=xbar(1:end-1);
            end
            
            x_vec = eval(['[',x,']','''']);
            xbar_vec=eval(['[',xbar,']','''']);
            
            
            u='';
            if obj.dim_u >0
                for i=1:obj.dim_u
                    eval(['syms',' ','u',num2str(i),' ','real'])
                    u=[u,'u',num2str(i),' '];
                end
                if u(end)==' '
                    u=u(1:end-1);
                end
            end
            u_vec = eval(['[',u,']','''']);
            
            if obj.Type == 'l'
                if obj.dim_u >0
                    sys_par = obj.A*x_vec+obj.B*u_vec;
                else
                    sys_par = obj.A*x_vec;
                end
                
            else
                if isempty(obj.N)
                    disp('Selected Bilinear model as type and N-matrix is empty!');
                    return;
                end
                sys_bi = obj.N*kron(u_vec,x_vec);
                
                sys_par = obj.A*x_vec+obj.B*u_vec + sys_bi;
                
            end
            
            d='';
            if obj.dim_d >0
                for i=1:obj.dim_d
                    eval(['syms',' ','d',num2str(i),' ','real'])
                    d=[d,'d',num2str(i),' '];
                end
                if d(end)==' '
                    d=d(1:end-1);
                end
                d_vec = eval(['[',d,']','''']);
                
                sys_mod       = sys_par + obj.F*d_vec;
                %%%%%%%%% Finalization of the kernel %%%%%%%%%%%%
                sys.tr=eval(['matlabFunction(sys_mod,''vars'',[',x,' ',u,' ',d,'])']);
                
            else
                

                %%%%%%%%% Finalization of the kernel %%%%%%%%%%%%
%                 Variance
                if obj.dim == 4
                    sys_mod       = obj.A*x_vec+obj.B*u_vec +[3.43635813345647;2.92724185944141;21.7012500000000;21.7012500000000];

                    VarTz1=(0.02)^2;%/60^2;
                    VarTz2=(0.01)^2;%/60^2;
                    VarR1 =(0.1)^2;%/60^2;
                    VarR2 =(0.08)^2;%/60^2;

                    %Resulting Sigma matrix
                    Sigma(1,1)=VarTz1*obj.dt;
                    Sigma(2,2)=VarTz2*obj.dt;
                    Sigma(3,3)=VarR1*obj.dt;
                    Sigma(4,4)=VarR2*obj.dt;
                else
                    sys_mod       = obj.A*x_vec+obj.B*u_vec +[4.3576,3.6611]';

                    VarTz1=(0.02)^2;%/60^2;
                    VarTz2=(0.01)^2;%/60^2;
                  

                    %Resulting Sigma matrix
                    Sigma(1,1)=VarTz1*obj.dt;
                    Sigma(2,2)=VarTz2*obj.dt;
                  
                end
                
                %Creation of the normal distribution
                mat=-0.5*(xbar_vec-sys_mod)'*Sigma^(-1)*(xbar_vec-sys_mod); % Matrix multiplication of the part inside the exponent of the normal distribution
                sys_mod=sqrt((2*pi)^obj.dim*det(Sigma))^-1*exp(mat); % The normal distribution
                sys.tr= eval(['matlabFunction(sys_mod,''vars'',[',x,' ',xbar,' ',u,'])']);
%                 if obj.dim_u > 0
%                     sys.tr= eval(['matlabFunction(sys_mod,''vars'',[',x,' ',u,'])']);
%                 else
%                      sys.tr= eval(['matlabFunction(sys_mod,''vars'',[',x,'])']);
%                 end
                
                
            end
            
            if obj.Noise == 's'
                s='';
                for i=1:obj.dim
                    eval(['syms',' ','s',num2str(i),' ','real']);
                    s=[s,'s',num2str(i),' '];
                end
                if s(end)==' '
                    s=s(1:end-1);
                end
                s_vec = eval(['[',s,']','''']);
                
                sys_mod       = sys_mod + obj.sigma*s_vec;
                %%%%%%%%% Finalization of the kernel %%%%%%%%%%%%
                sys.tr=eval(['matlabFunction(sys_mod,''vars'',[',x,' ',u,' ',d,' ',s,'])']);
            end
            
            
            
        end
        %%%%%%%%% Execute model over time T %%%%%%%%%%%%
        function y = runModel(sys,x_init, U,D,  T)
            
            if size(sys.A,2) ~= size(x_init,1)
                disp('Incorrect initial conditions');
                return;
            end
            
            if size(sys.B,2) ~= size(U,2)
                disp('Incorrect input signal');
                return;
            end
            if size(sys.F,2) ~= size(D)
                disp('Incorrect disturbance signal');
                return;
            end
            
            y      = zeros(size(sys.C,2),T);
            x      = zeros(size(sys.A,2),T);
            s      = zeros(size(sys.A,2),T);
            switch size(sys.A,2)
                case 1
                    switch size(sys.B,2)
                        case 0
                            x(:,1)=  sys.tr(x_init(1,1),D(1,1),D(1,2));
                            for i = 1:T
                              x(:,i+1) = sys.tr(x(1,i),D(i,1),D(i,2)); % FIX UP
                           
                            end
                            y = sys.C*x;
                        case 1
                            switch size(sys.F,2)
                                case 0
                                    if sys.Noise == 'd'
                                        x(:,1)=  sys.tr(x_init(1,1),U(1,1));
                                    else
                                        x(:,1)=  sys.tr(x_init(1,1),U(1,1),0);
                                    end
                                    for i = 1:T
                                        if sys.Noise == 'd'
                                            x(:,i+1) = sys.tr(x(1,i),U(i,1)); % FIX UP
                                        else
                                            s(1,i) = sum(sys.dW((i-1)+1:i)); % Weiner Increment
                                            x(:,i+1) = sys.tr(x(1,i),U(i,1),s(1,i));
                                        end
                                        y(:,i) = sys.C*x(:,i);
                                    end
                                case 1
                                    if sys.Noise == 'd'
                                        x(:,1) =  sys.tr(x_init,U(1,1),D(1,1));
                                    else
                                        %sum(sys.dW(1:1));
                                        x(:,1) =  sys.tr(x_init,U(1,1),D(1,1),sum(sys.dW(1:1)));
                                    end
                                    
                                    for i = 1:T
                                        if sys.Noise == 'd'
                                            x(:,i+1) = sys.tr(x(1,i),U(i,1),D(i,1)); % FIX UP
                                        else
                                            s(1,i) = sum(sys.dW((i-1)+1:i)); % Weiner Increment
                                            x(:,i+1) = sys.tr(x(1,i),U(i,1),D(i,1),s(1,i));
                                        end
                                        y(:,i) = sys.C*x(:,i);
                                    end
                                case 2
                                    if sys.Noise == 'd'
                                        x(:,1) =  sys.tr(x_init,U(1,1),D(1,1),D(1,2));
                                    else
                                        x(:,1) =  sys.tr(x_init,U(1,1),D(1,1),D(1,2),0);
                                    end
                                    for i = 1:T
                                        if sys.Noise == 'd'
                                            x(:,i+1) = sys.tr(x(1,i),U(i,1),D(i,1),D(i,2)); % FIX UP
                                        else
                                            s(1,i) = sum(sys.dW((i-1)+1:i)); % Weiner Increment
                                            x(:,i+1) = sys.tr(x(1,i),U(i,1),D(i,1),D(i,2),s(1,i));
                                        end
                                        y(:,i) = sys.C*x(:,i);
                                    end
                            end
                            
                            
                        case 2
                            switch size(sys.F,2)
                                case 0
                                    if sys.Noise == 'd'
                                        x(:,1)=  sys.tr(x_init(1,1),U(1,1),U(1,2));
                                    else
                                        x(:,1)=  sys.tr(x_init(1,1),U(1,1),U(1,2),0);
                                    end
                                    for i = 1:T
                                        if sys.Noise == 'd'
                                            x(:,i+1) = sys.tr(x(1,i),U(i,1),U(i,2)); % FIX UP
                                        else
                                            s(1,i) = sum(sys.dW((i-1)+1:i)); % Weiner Increment
                                            x(:,i+1) = sys.tr(x(1,i),U(i,1),U(i,2),s(1,i));
                                        end
                                        y(:,i) = sys.C*x(:,i);
                                    end
                                case 1
                                    if sys.Noise == 'd'
                                        x(:,1)=  sys.tr(x_init(1,1),U(1,1),U(1,2),D(1,1));
                                    else
                                        x(:,1)=  sys.tr(x_init(1,1),U(1,1),U(1,2),D(1,1),0);
                                    end
                                    for i = 1:T
                                        if sys.Noise == 'd'
                                            x(:,i+1) = sys.tr(x(1,i),U(i,1),U(i,2),D(i,1)); % FIX UP
                                        else
                                            s(1,i) = sum(sys.dW((i-1)+1:i)); % Weiner Increment
                                            x(:,i+1) = sys.tr(x(1,i),U(i,1),U(i,2),D(i,1),s(1,i));
                                        end
                                        y(:,i) = sys.C*x(:,i);
                                    end
                                case 2
                                    if sys.Noise == 'd'
                                        x(:,1)=  sys.tr(x_init(1,1),U(1,1),U(1,2),D(1,1),D(1,2));
                                    else
                                        x(:,1)=  sys.tr(x_init(1,1),U(1,1),U(1,2),D(1,1),D(1,2),0);
                                    end
                                    for i = 1:T
                                        if sys.Noise == 'd'
                                            x(:,i+1) = sys.tr(x(1,i),U(i,1),U(i,2),D(i,1),D(i,2)); % FIX UP
                                        else
                                            s(1,i) = sum(sys.dW((i-1)+1:i)); % Weiner Increment
                                            x(:,i+1) = sys.tr(x(1,i),U(i,1),U(i,2),D(i,1),D(i,2),s(1,i));
                                        end
                                        y(:,i) = sys.C*x(:,i);
                                    end
                            end
                        case 3
                            switch size(sys.F,2)
                                case 0
                                    if sys.Noise == 'd'
                                        x(:,1)=  sys.tr(x_init(1,1),U(1,1),U(1,2),U(1,3));
                                    else
                                        x(:,1)=  sys.tr(x_init(1,1),U(1,1),U(1,2),U(1,3),0);
                                    end
                                    for i = 1:T
                                        if sys.Noise == 'd'
                                            x(:,i+1) = sys.tr(x(1,i),U(i,1),U(i,2),U(i,3)); % FIX UP
                                        else
                                            s(1,i) = sum(sys.dW((i-1)+1:i)); % Weiner Increment
                                            x(:,i+1) = sys.tr(x(1,i),U(i,1),U(i,2),U(i,3),s(1,i));
                                        end
                                        y(:,i) = sys.C*x(:,i);
                                    end
                                case 1
                                    if sys.Noise == 'd'
                                        x(:,1)=  sys.tr(x_init(1,1),U(1,1),U(1,2),U(1,3),D(1,1));
                                    else
                                        x(:,1)=  sys.tr(x_init(1,1),U(1,1),U(1,2),U(1,3),D(1,1),0);
                                    end
                                    for i = 1:T
                                        if sys.Noise == 'd'
                                            x(:,i+1) = sys.tr(x(1,i),U(i,1),U(i,2),U(i,3),D(i,1));
                                        else
                                            s(1,i) = sum(sys.dW((i-1)+1:i)); % Weiner Increment
                                            x(:,i+1) = sys.tr(x(1,i),U(i,1),U(i,2),U(i,3),D(i,1),s(1,i));
                                        end
                                        y(:,i) = sys.C*x(:,i);
                                    end
                                case 2
                                    if sys.Noise == 'd'
                                        x(:,1)=  sys.tr(x_init(1,1),U(1,1),U(1,2),U(1,3),D(1,1),D(1,2));
                                    else
                                        x(:,1)=  sys.tr(x_init(1,1),U(1,1),U(1,2),U(1,3),D(1,1),D(1,2),0);
                                    end
                                    for i = 1:T
                                        if sys.Noise == 'd'
                                            x(:,i+1) = sys.tr(x(1,i),U(i,1),U(i,2),U(i,3),D(i,1),D(i,2));
                                        else
                                            s(1,i) = sum(sys.dW((i-1)+1:i)); % Weiner Increment
                                            x(:,i+1) = sys.tr(x(1,i),U(i,1),U(i,2),U(i,3),D(i,1),D(i,2),s(1,i));
                                        end
                                        y(:,i) = sys.C*x(:,i);
                                    end
                            end
                    end
                case 2
                    switch size(sys.B,2)
                        case 0
                            x(:,1)=  sys.tr(x_init(1,1),x_init(2,1),D(1,1),D(1,2),D(1,3));   
                            for i = 1:T
                               x(:,i+1) = sys.tr(x(1,i),x(2,i),D(i,1),D(i,2),D(i,3));   
                            end
                            y = sys.C*x;
                                  
                        case 1
                            switch size(sys.F,2)
                                case 0
                                    if sys.Noise == 'd'
                                        x(:,1)=  sys.tr(x_init(1,1),x_init(2,1),U(1,1));
                                    else
                                        x(:,1)=  sys.tr(x_init(1,1),x_init(2,1),U(1,1),[0 0]);
                                    end
                                    for i = 1:T
                                        if sys.Noise == 'd'
                                            x(:,i+1) = sys.tr(x(1,i),x(2,i),U(i,1));
                                        else
                                            s(:,i) = sum(sys.dW((i-1)+1:i)); % Weiner Increment
                                            x(:,i+1) = sys.tr(x(1,i),x(2,i),U(i,1),s(1,i),s(2,i));
                                        end
                                        y(:,i) = sys.C*x(:,i);
                                    end
                                case 1
                                    if sys.Noise == 'd'
                                        x(:,1)=  sys.tr(x_init(1,1),x_init(2,1),U(1,1),D(1,1));
                                    else
                                        x(:,1)= sys.tr(x_init(1,1),x_init(2,1),U(1,1),D(1,1),s(1,1),s(2,1));
                                    end
                                    for i = 1:T
                                        if sys.Noise == 'd'
                                            x(:,i+1) = sys.tr(x(1,i),x(2,i),U(i,1),D(i,1));
                                        else
                                            s(:,i) = sum(sys.dW((i-1)+1:i)); % Weiner Increment
                                            x(:,i+1) = sys.tr(x(1,i),x(2,i),U(i,1),D(i,1),s(1,i),s(2,i));
                                        end
                                        y(:,i) = sys.C*x(:,i);
                                    end
                                case 2
                                    if sys.Noise == 'd'
                                        x(:,1)=  sys.tr(x_init(1,1),x_init(2,1),U(1,1),D(1,1),D(1,2));
                                    else
                                        x(:,1)= sys.tr(x_init(1,1),x_init(2,1),U(1,1),D(1,1),D(1,2),0,0);
                                    end
                                    for i = 1:T
                                        if sys.Noise == 'd'
                                            x(:,i+1) = sys.tr(x(1,i),x(2,i),U(i,1),D(i,1),D(i,2));
                                        else
                                            s(:,i) = sum(sys.dW((i-1)+1:i)); % Weiner Increment
                                            x(:,i+1) = sys.tr(x(1,i),x(2,i),U(i,1),D(i,1),D(i,2),s(1,i),s(2,i));
                                        end
                                        y(:,i) = sys.C*x(:,i);
                                    end
                                 case 4
                                    if sys.Noise == 'd'
                                        x(:,1)=  sys.tr(x_init(1,1),x_init(2,1),U(1,1),D(1,1),D(1,2),D(1,3),D(1,4));
                                    else
                                        x(:,1)= sys.tr(x_init(1,1),x_init(2,1),U(1,1),D(1,1),D(1,2),D(1,3),D(1,4),[0 0]);
                                    end
                                    for i = 1:T
                                        if sys.Noise == 'd'
                                            x(:,i+1) = sys.tr(x(1,i),x(2,i),U(i,1),D(i,1),D(i,2),D(i,3),D(i,4));
                                        else
                                            s(:,i) = sum(sys.dW((i-1)+1:i)); % Weiner Increment
                                            x(:,i+1) = sys.tr(x(1,i),x(2,i),U(i,1),D(i,1),D(i,2),D(i,3),D(i,4),s(1,i),s(2,i));
                                        end
                                     
                                    end
                                    y = sys.C*x;
                            end
                            
                        case 2
                            switch size(sys.F,2)
                                case 0
                                    if sys.Noise == 'd'
                                        x(:,1)=  sys.tr(x_init(1,1),x_init(2,1),U(1,1),U(1,2));
                                    else
                                        x(:,1)= sys.tr(x_init(1,1),x_init(2,1),U(1,1),U(1,2),0, 0);
                                    end
                                    for i = 1:T
                                        if sys.Noise == 'd'
                                            x(:,i+1) = sys.tr(x(1,i),x(2,i),U(i,1),U(i,2));
                                        else
                                            s(:,i) = sum(sys.dW((i-1)+1:i)); % Weiner Increment
                                            x(:,i+1) = sys.tr(x(1,i),x(2,i),U(i,1),U(i,2),s(1,i),s(2,i));
                                        end
                                        y(:,i) = sys.C*x(:,i);
                                    end
                                case 1
                                    if sys.Noise == 'd'
                                        x(:,1)=  sys.tr(x_init(1,1),x_init(2,1),U(1,1),U(1,2),D(1,1));
                                    else
                                        x(:,1)= sys.tr(x_init(1,1),x_init(2,1),U(1,1),U(1,2),D(1,1),0, 0);
                                    end
                                    for i = 1:T
                                        if sys.Noise == 'd'
                                            x(:,i+1) = sys.tr(x(1,i),x(2,i),U(i,1),U(i,2),D(i,1));
                                        else
                                            s(:,i) = sum(sys.dW((i-1)+1:i)); % Weiner Increment
                                            x(:,i+1) = sys.tr(x(1,i),x(2,i),U(i,1),U(i,2),D(i,1),s(1,i),s(2,i));
                                        end
                                        y(:,i) = sys.C*x(:,i);
                                    end
                                case 2
                                    if sys.Noise == 'd'
                                        x(:,1)=  sys.tr(x_init(1,1),x_init(2,1),U(1,1),U(1,2),D(1,1),D(1,2));
                                    else
                                        x(:,1)= sys.tr(x_init(1,1),x_init(2,1),U(1,1),U(1,2),D(1,1),D(1,2),0, 0);
                                    end
                                    for i = 1:T
                                        if sys.Noise == 'd'
                                            x(:,i+1) = sys.tr(x(1,i),x(2,i),U(i,1),U(i,2),D(i,1),D(i,2));
                                        else
                                            s(:,i) = sum(sys.dW((i-1)+1:i)); % Weiner Increment
                                            x(:,i+1) = sys.tr(x(1,i),x(2,i),U(i,1),U(i,2),D(i,1),D(i,2),s(1,i),s(2,i));
                                        end
                                        y(:,i) = sys.C*x(:,i);
                                    end
                                case 3
                                    if sys.Noise == 'd'
                                        x(:,1)=  sys.tr(x_init(1,1),x_init(2,1),U(1,1),U(1,2),D(1,1),D(1,2),D(1,3));
                                    else
                                        x(:,1)= sys.tr(x_init(1,1),x_init(2,1),U(1,1),U(1,2),D(1,1),D(1,2),D(1,3),0, 0);
                                    end
                                    for i = 1:T
                                        if sys.Noise == 'd'
                                            x(:,i+1) = sys.tr(x(1,i),x(2,i),U(i,1),U(i,2),D(i,1),D(i,2),D(i,3));
                                        else
                                            s(:,i) = sum(sys.dW((i-1)+1:i)); % Weiner Increment
                                            x(:,i+1) = sys.tr(x(1,i),x(2,i),U(i,1),U(i,2),D(i,1),D(i,2),D(i,3),s(1,i),s(2,i));
                                        end
                                        y(:,i) = sys.C*x(:,i);
                                    end
                                case 4
                                    if sys.Noise == 'd'
                                        x(:,1)=  sys.tr(x_init(1,1),x_init(2,1),U(1,1),U(1,2),D(1,1),D(1,2),D(1,3),D(1,4));
                                    else
                                        x(:,1)= ys.tr(x_init(1,1),x_init(2,1),U(1,1),U(1,2),D(1,1),D(1,2),D(1,3),D(1,4),0, 0);
                                    end
                                    for i = 1:T
                                        if sys.Noise == 'd'
                                            x(:,i+1) = sys.tr(x(1,i),x(2,i),U(i,1),U(i,2),D(i,1),D(i,2),D(i,3),D(i,4));
                                        else
                                            s(:,i) = sum(sys.dW((i-1)+1:i)); % Weiner Increment
                                            x(:,i+1) = sys.tr(x(1,i),x(2,i),U(i,1),U(i,2),D(i,1),D(i,2),D(i,3),D(i,4),s(1,i),s(2,i));
                                        end
                                        y(:,i) = sys.C*x(:,i);
                                    end
                            end
                            
                            
                    end
                case 3
                    switch size(sys.B,2)
                        case 1
                            switch size(sys.F,2)
                                case 0
                                    if sys.Noise == 'd'
                                        x(:,1)=  sys.tr(x_init(1,1),x_init(2,1),x_init(3,1),U(1,1));
                                    else
                                        x(:,1)= sys.tr(x_init(1,1),x_init(2,1),x_init(3,1),U(1,1),0, 0, 0);
                                    end
                                    for i = 1:T
                                        if sys.Noise == 'd'
                                            x(:,i+1) = sys.tr(x(1,i),x(2,i),x(3,i), U(i,1));
                                        else
                                            s(:,i) = sum(sys.dW((i-1)+1:i)); % Weiner Increment
                                            x(:,i+1) = sys.tr(x(1,i),x(2,i),x(3,i), U(i,1),s(1,i),s(2,i),s(3,i));
                                        end
                                        y(:,i) = sys.C*x(:,i);
                                    end
                                case 1
                                    if sys.Noise == 'd'
                                        x(:,1)=  sys.tr(x_init(1,1),x_init(2,1),x_init(3,1),U(1,1),D(1,1));
                                    else
                                        x(:,1)= sys.tr(x_init(1,1),x_init(2,1),x_init(3,1),U(1,1),D(1,1),0, 0, 0);
                                    end
                                    for i = 1:T
                                        if sys.Noise == 'd'
                                            x(:,i+1) = sys.tr(x(1,i),x(2,i),x(3,i), U(i,1),D(i,1));
                                        else
                                            s(:,i) = sum(sys.dW((i-1)+1:i)); % Weiner Increment
                                            x(:,i+1) = sys.tr(x(1,i),x(2,i),x(3,i), U(i,1),D(i,1),s(1,i),s(2,i),s(3,i));
                                        end
                                        y(:,i) = sys.C*x(:,i);
                                    end
                                case 2
                                    if sys.Noise == 'd'
                                        x(:,1)=  sys.tr(x_init(1,1),x_init(2,1),x_init(3,1),U(1,1),D(1,1),D(1,2));
                                    else
                                        x(:,1)= sys.tr(x_init(1,1),x_init(2,1),x_init(3,1),U(1,1),D(1,1),D(1,2),0, 0, 0);
                                    end
                                    for i = 1:T
                                        if sys.Noise == 'd'
                                            x(:,i+1) = sys.tr(x(1,i),x(2,i),x(3,i), U(i,1),D(i,1),D(i,2));
                                        else
                                            s(:,i) = sum(sys.dW((i-1)+1:i)); % Weiner Increment
                                            x(:,i+1) = sys.tr(x(1,i),x(2,i),x(3,i), U(i,1),D(i,1),D(i,2),s(1,i),s(2,i),s(3,i));
                                        end
                                        y(:,i) = sys.C*x(:,i);
                                    end
                            end
                            
                            
                        case 2
                            switch size(sys.F,2)
                                case 0
                                    if sys.Noise == 'd'
                                        x(:,1)=  sys.tr(x_init(1,1),x_init(2,1),x_init(3,1),U(1,1),U(1,2));
                                    else
                                        x(:,1)= sys.tr(x_init(1,1),x_init(2,1),x_init(3,1),U(1,1),U(1,2),0, 0, 0);
                                    end
                                    for i = 1:T
                                        if sys.Noise == 'd'
                                            x(:,i+1) = sys.tr(x(1,i),x(2,i),x(3,i),U(i,1),U(i,2));
                                        else
                                            s(:,i) = sum(sys.dW((i-1)+1:i)); % Weiner Increment
                                            x(:,i+1) = sys.tr(x(1,i),x(2,i),x(3,i),U(i,1),U(i,2),s(1,i),s(2,i),s(3,i));
                                        end
                                        y(:,i) = sys.C*x(:,i);
                                    end
                                case 1
                                    if sys.Noise == 'd'
                                        x(:,1)=  sys.tr(x_init(1,1),x_init(2,1),x_init(3,1),U(1,1),U(1,2),D(1,1));
                                    else
                                        x(:,1)=  sys.tr(x_init(1,1),x_init(2,1),x_init(3,1),U(1,1),U(1,2),D(1,1),0, 0, 0);
                                    end
                                    for i = 1:T
                                        if sys.Noise == 'd'
                                            x(:,i+1) = sys.tr(x(1,i),x(2,i),x(3,i),U(i,1),U(i,2),D(i,1));
                                        else
                                            s(:,i) = sum(sys.dW((i-1)+1:i)); % Weiner Increment
                                            x(:,i+1) = sys.tr(x(1,i),x(2,i),x(3,i),U(i,1),U(i,2),D(i,1),s(1,i),s(2,i),s(3,i));
                                        end
                                        y(:,i) = sys.C*x(:,i);
                                    end
                                case 2
                                    if sys.Noise == 'd'
                                        x(:,1)=  sys.tr(x_init(1,1),x_init(2,1),x_init(3,1),U(1,1),U(1,2),D(1,1),D(1,2));
                                    else
                                        x(:,1)= sys.tr(x_init(1,1),x_init(2,1),x_init(3,1),U(1,1),U(1,2),D(1,1),D(1,2),0, 0, 0);
                                    end
                                    for i = 1:T
                                        if sys.Noise == 'd'
                                            x(:,i+1) = sys.tr(x(1,i),x(2,i),x(3,i),U(i,1),U(i,2),D(i,1),D(i,2));
                                        else
                                            s(:,i) = sum(sys.dW((i-1)+1:i)); % Weiner Increment
                                            x(:,i+1) = sys.tr(x(1,i),x(2,i),x(3,i),U(i,1),U(i,2),D(i,1),D(i,2),s(1,i),s(2,i),s(3,i));
                                        end
                                        y(:,i) = sys.C*x(:,i);
                                    end
                            end
                            
                            
                    end
                case 4
                    switch size(sys.F,2)
                        case 1
                                if sys.Noise == 'd'
                                    x(:,1)=  sys.tr(x_init(1,1),x_init(2,1),x_init(3,1),x_init(4,1),U(1,1),D(1,1));
                                else
                                   x(:,1)= sys.tr(x_init(1,1),x_init(2,1),x_init(3,1),x_init(4,1),U(1,1),D(1,1),0, 0, 0,0); 
                                end
                            
                            for i = 1:T
                                if sys.Noise == 'd'
                                    x(:,i+1) = sys.tr(x(1,i),x(2,i),x(3,i),x(4,i), U(i,1), D(i,1));
                                else
                                    s(:,i) = sum(sys.dW((i-1)+1:i)); % Weiner Increment
                                    x(:,i+1) = sys.tr(x(1,i),x(2,i),x(3,i),x(4,i),U(i,1),D(i,1),s(1,i),s(2,i),s(3,i),s(4,i)); 
                                end
                                
                                y(:,i) = sys.C*x(:,i);
                            end
                        case 3
                            
                            x(:,1)=  sys.tr(x_init(1,1),x_init(2,1),x_init(3,1),x_init(4,1),U(1,1),D(1,1),D(1,2),D(1,3));
                            
                            for i = 1:T
                                
                                x(:,i+1) = sys.tr(x(1,i),x(2,i),x(3,i),x(4,i), U(i,1), D(i,1),D(i,2),D(i,3));
                                
                                y(:,i) = sys.C*x(:,i);
                            end
                    end
                    
                    
                case 7
                    switch size(sys.B,2)
                        case 2
                            if sys.Noise == 'd'
                                x(:,1) =  sys.tr(x_init,U(1,1),D(1,1),D(1,2));
                            else
                                x(:,1) =  sys.tr(x_init,U(1,1),D(1,1),D(1,2),0);
                            end
                            for i = 1:T
                                if sys.Noise == 'd'
                                    x(:,i+1) = sys.tr(x(1,i),U(i,1),D(i,1),D(i,2)); % FIX UP
                                else
                                    s(1,i) = sum(sys.dW((i-1)+1:i)); % Weiner Increment
                                    x(:,i+1) = sys.tr(x(1,i),U(i,1),D(i,1),D(i,2),s(1,i));
                                end
                                y(:,i) = sys.C*x(:,i);
                            end
                    end
            end
            
            
            
        end
        
        function S = stepResponse(sys,U,D,T)
            x      = zeros(size(sys.A,2),T);
            nu     = size(U,2);
            x_init = x(:,1);
            
            
            for i = 1:nu
                x(:,1) = zeros(size(sys.A,2),1);
                U(:,i) = ones(T,1);
                U(1:5,i) = zeros(5,1);
                y = runModel(sys, x_init,U,D,T);
                plot(1:T,y);
                if size(y,1) == 1
                    S(i) = stepinfo(y,1:T,y(:,end));
                else
                    S(i,1) = stepinfo(y(1,:),1:T,y(1,end));
                    S(i,2) = stepinfo(y(2,:),1:T,y(2,end));
                end
                
            end
            
        end
        
        
        
    end
    
end

