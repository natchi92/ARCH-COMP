function [Safe2D, Safe_err] = get2DSafeSet(maxTemp, minTemp, Epsilon)
% All are normalized

ubound      = Polyhedron([-100,100]');% input bound
Safe        = Polyhedron([minTemp,maxTemp]'); % temperature range
Safe_err    = Safe-Polyhedron([-Epsilon,Epsilon]');

Safe2D      = ubound*Safe_err;


end
