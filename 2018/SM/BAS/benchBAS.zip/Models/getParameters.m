% List of parameters and there values
%--------- Material properties   -------%
Materials.air.Cpa   = 1204/1e3;                                                 % thermal capacity of air [J/kgK]
Materials.air.rhoa  = 1.2;                                                  % density of air [kg/m3]
Materials.water.Cpw = 4180/1e3;                                                 % thermal capacity of water [J/kgK]
Materials.water.rhow= 1000/1e3;                                                 % density of water [kg/m3]
Materials.concrete.Cn = 880/1e3;                                                % thermal capacity of concrete [J/kgK]
Materials.concrete.rhon = 2.4e3/1e3;                                            % density of concrete [kg/m3]

%--------- Boiler Parameters  -------%
% Gas Boiler, AMBI simulator
%Boiler.Pb   = 2e4;                                                         % Boiler rated output power [W]
%Boiler.hb   = ;                                                            % Conductive heat coefficient of boiler [W/K]
%Boiler.Ab   = ;                                                            % Contact area for conduction in boiler [m2]
Boiler.taub = 5*60/60;                                                         % Time constant of boiler [s]
Boiler.kb   = 348.15 - 273.15;                                              % Steady-state temperature of the boiler (75degC) [K]
Boiler.sigma = 5;
Splitter.uv = 0;                                                          % Water flow Splitter [-]

%--------- Chiller Parameters -------%
%Chiller.Qc = ;                                                              % Cooling power of the chiller [W]

%--------- FCU     Parameters -------%
%FCU.UA_fcu =    ;                                                           % Overall transmittance area factor of fcu [W/m2K]
FCU.Vfcu   = 0.06;                                                          % Volume of fcu [m3]
FCU.Afcu   = 0.26;                                                          % Contact area for conduction in fcu [m2]          
FCU.mfcu_l = 0.16;                                                          % FCU mass air flow when fan is in low mode [m3/s]
FCU.mfcu_m = 0.175;                                                         % FCU mass air flow when fan is in med mode [m3/s]
FCU.mfcu_h = 0.19;                                                          % FCU mass air flow when fan is in high mode [m3/s]


%--------- AHU Parameters     -------%
%AHU.UA_ahu = ;                                                              % Overall transmittance area factor of ahu [W/m2K]
AHU.Vahu =.5 ;      %TO BE CHANGED                                                           % Volume of ahu [m3]
%AHU.hahu = ;                                                                % Conductive heat coefficient of ahu [W/K]
%AHU.Aahu = ;                                                                % Contact area for conduction in ahu [m2]
%AHU.mahu_l = ;                                                              % AHU mass air flow when fan is in low mode [kg/s]
%AHU.mahu_h = ;                                                              % AHU mass air flow when fan is in high mode [kg/s]
AHU.sa.k0 = 0.00121;%0.01407;%65.723940595314872/60;
AHU.sa.k1 = 1.0953;%62974;%0.072982431709651/60;
AHU.rw.k0 = 0.65346;%22.416/60;
AHU.rw.k1 = 0.06469;%0.1212/60;
AHU.sa.sigma =0.1;
AHU.rw.sigma =0.1;
AHU.w_max    = 10/60;
Mixer.um     = 0.5;

%--------- Zone Parameters    -------%
%--------- Zone 1             -------%
Zone1.Cz   =  341.9331/30;%/60;%;                                                        % Thermal capacitance of zone [J/kgK]
Zone1.Cn   =  36.3759;                                                  % Thermal capacitance of neighbouring wall [J/kgK]
Zone1.Rout =  .17257598615466101*60;%                                                      % Resistance of walls connected to outside [K/W]
Zone1.Rn   =  .12649687021924599*60;%                                                     % Resistance of walls connected to neighbouring wall [K/W]
Zone1.mu   =  0.000199702104146;                                             % Q_occ coefficient in \muCO_2 + \zeta [-]
Zone1.zeta =  0.188624079752965;
Zone1.alpha=  0.044;                                                         % Absorptivity coefficient of wall [W/m2K]
Zone1.A_w  =  1.352;                                                         % Area of window [m2]
Zone1.iota =  0.359444194048431;                                                        % Q_solar coefficient in \alpha A_w(\iota T_out + \gamma) [-]
Zone1.gamma=  1.622446039686184;
Zone1.m    = 10/60;                                                                % Fixed mass supply air
Zone1.Tz.sigma = 0.02;
Zone1.Te.sigma = 0.01;
%54:56J=K and 0:023K=W,
%--------- Zone 2             -------%
Zone2.Cz   =  321.9331/30;                                                        % Thermal capacitance of zone [J/kgK]
Zone2.Cn   =  33.3759;                                                  % Thermal capacitance of neighbouring wall [J/kgK]
Zone2.Rout =  0.1575*60;                                                       % Resistance of walls connected to outside [K/W]
Zone2.Rn   =  0.1496*60;                                                       % Resistance of walls connected to neighbouring wall [K/W]
Zone2.mu   =  5.805064e-6;                                             % Q_occ coefficient in \muCO_2 + \zeta [-]
Zone2.zeta =  -0.003990;
Zone2.alpha=  0.044;                                                         % Absorptivity coefficient of wall [W/m2K]
Zone2.A_w  =  10.797;                                                         % Area of window [m2]
Zone2.iota =  0.03572;                                                        % Q_solar coefficient in \alpha A_w(\iota T_out + \gamma) [-]
Zone2.gamma=  0.06048;
Zone2.m    = 10/60;                                                                % Fixed mass supply air
Zone2.Tz.sigma = .02;
Zone2.Te.sigma = .01;

%--------- Radiator Parameters-------%

Radiator.k0      = 1.1574;%0.1321;%69.4440000000000/60;
Radiator.k1      = 0.0667;%0.4308;%3.138/60;
Radiator.Vrad    = 0.1;     %TO BE CHANGED                                     % Volume of radiator [m3]
Radiator.hrad    = 1e-3;   %TO BE CHANGED                                      % Conductive heat coefficient of radiator [W/K]
Radiator.Arad    = 1e-4;    %TO BE CHANGED                                     % Contact area for conduction in radiator [m2]
Radiator.w_max   = 10/60;                                                     % Water flow
Radiator.Z1.Prad = 3*600/1000; 
Radiator.Z2.Prad = 5*600/1000;                                                 % Rated output power of radiator [kW]
Radiator.p8      = 0.0250;                                                     % Coefficients of \deltaT [-]
Radiator.p9      = -0.02399;
Radiator.rw.sigma= 0.1;
