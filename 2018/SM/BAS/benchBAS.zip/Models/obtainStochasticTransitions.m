function Pz = obtainStochasticTransitions(nz,zrep,delta_z)
%mu - zrep(1)
% sigma -1
Pz = zeros(nz,nz);
for i=1:nz
    Pz(i,:) = normpdf(zrep,zrep(i),1)*delta_z;
end

end
