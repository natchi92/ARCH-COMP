clear;
addContainingDirAndSubDir;

%%%% Perform CS1 benchmark
Cs1;


pause;

%%%%% Perform CS2 benchmark

Cs2;