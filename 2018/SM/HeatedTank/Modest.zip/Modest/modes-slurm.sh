#!/usr/bin/env bash
#
# Author:  Carlos E. Budde
# Date:    31.10.2017
#
#   Launch a distributed Modest experiment in SLURM
#   using the SBATCH configuration described below,
#   or the parameters specified by the user.


####  SCRIPT VARIABLES  #######################################################

declare -a ALLARGS=$@
# Invocation parameters
PPART=partition
PNODES=nodes
PCORES=cores
PTIME=timeout-slurm
# SLURM variables
SPART=SLURM_PARTITION
SNODES=SLURM_NODES
SCORES=SLURM_CORES_PER_NODE
STIME=SLURM_TLIMIT


####  DEFAULT SLURM CONFIGURATION  ############################################

# Job queue
eval $SPART=r415
# Number of nodes to use as slaves
eval $SNODES=4
# OPTIONAL: Number of core-threads used per node (when unset all cores are used)
eval $SCORES=8
# OPTIONAL: Execution time limit in the format days-hours:minutes:seconds
eval $STIME=


####  PARAMETERS CHECK & SBATCH CONFIGURATION  ################################

usage() {
	echo -e "Usage: $0 -h,--help"
	echo -e "       $0 <modes-options-list> [SLURM_CONFIG]"
	echo
	echo -e "with SLURM_CONFIG consisting of one or several of:"
	echo -e "    --$PPART P\twhere P is the SLURM partition where the job"
	echo -e "    \t\t\twill be allocated"
	echo -e "    --$PNODES N\t\twhere N is the number of SLURM nodes which will"
	echo -e "    \t\t\thost a modes slave"
	echo -e "    --$PCORES C\t\twhere C is the number of cores/threads per node"
	echo -e "    \t\t\tused by the modes slaves"
	echo -e "    --$PTIME T\twhere T is a time limit in the SLURM format"
	echo -e "    \t\t\t(i.e. days-hours:minutes:seconds)"
}
extract_param() {
	local TMP=();
	local ARR=(${!1});
	local CFG=(${@:2});
	local PAR_NAME="--${CFG[0]}";
	local VAR_NAME=${CFG[1]};
	local VAR_VALUE=${CFG[2]};  # default value, if any
	for (( i=0 ; i<${#ARR[@]} ; i++ )); do
		[[ ${ARR[i]} == $PAR_NAME ]] \
			&& VAR_VALUE=${ARR[$((i+1))]} && i=$((i+1)) \
			|| TMP+=(${ARR[i]});
	done
	[ ! -z "$VAR_VALUE" ] && export $VAR_NAME=$VAR_VALUE;
	eval "$1=(\"\${TMP[*]}\")";
}
if [ $# -eq 1 ] && [[ $1 == "--help" || $1 == "-h" ]]; then
	usage && exit 0;
elif [ $# -lt 1 ] || [ $# -eq 1 ] && [[ $1 != "--help" && $1 != "-h" ]]; then
	echo "[ERROR] Bad invocation" && usage && exit 1;
fi
declare -a PAR;
echo "SLURM configuration:";
for CFG in PART NODES CORES TIME; do
	PAR=(`eval echo \\\$P$CFG` `eval echo \\\$S$CFG` `eval echo \\\${!S$CFG}`);
	extract_param ALLARGS ${PAR[@]};
	echo " - `eval echo \\\$P$CFG = \\\${!S$CFG}`";
done
unset -v PAR;


####  FIND MONO & MODES  ######################################################

MONO=`which mono`
if [ -z "$MONO" ]; then
	echo "[ERROR] A mono binary was not found in the environment"; exit 1;
else
	echo "Using mono binary $MONO";
fi
MODES="${BASH_SOURCE%/*}/modes.exe"
if [ -z "$MODES" ]; then
	echo "[ERROR] A modes binary was not found in the environment"; exit 1;
else
	echo "Using modes binary $MODES";
fi
runmodes() { $MONO $MODES $@; }
export MONO MODES;
export -f runmodes;


####  ALLOCATE SLURM RESOURCES  ###############################################

FRESH_FILE=`mktemp`;
FRESH_ID=${FRESH_FILE##*.};
JNAME="${FRESH_ID:0:2}_modeslurm";
FOUT_SERVERS="servers_${JNAME}.out";
TMP_SERVER=".server_${FRESH_ID}";
TMP_IPADDR=".IPaddr_${FRESH_ID}";
# IP address registry of slave nodes:
export TMP_IPADDR && touch $TMP_IPADDR;
[ ! -z "${!SCORES}" ] && [ ${!SCORES} -gt 0 ] && SERVERCORES="-J ${!SCORES}";
echo -e "
  echo \"[ \`whoami\` @ \`hostname\` ] Has \`nproc --all\` cores\";
  echo \"CPU: \`gawk '{FS=\":\"}/model name/{print \$2;exit}' /proc/cpuinfo\`\";
  echo -n \"\`hostname --ip-address\`,\" >> ${TMP_IPADDR}_\`hostname\`.dat;
  runmodes --server $SERVERCORES -O $FOUT_SERVERS -Y;
  echo \"[ERROR] Being here means \\\"modes --server\\\" invocation failed\";
  " >> $TMP_SERVER;
unset SERVERCORES;
# SLURM batch allocation (i.e. slave nodes setup):
echo "Allocating SLURM nodes for the modes slaves";
echo "SLURM job name: $JNAME";
echo "Output file (server nodes): $FOUT_SERVERS";
[ -z "${!STIME}" ] && STO=() || STO=("-t" "${!STIME}");
salloc -J $JNAME ${STO[*]}  \
	--partition=${!SPART}   \
	--nodes=${!SNODES}      \
	--ntasks-per-node=1     \
	--exclusive             \
	srun --preserve-env -o $FOUT_SERVERS -e $FOUT_SERVERS bash $TMP_SERVER &
# Wait for all nodes to register their IP addresses
set +e;
while
	NUM_IPADDR=$(ls -l ${TMP_IPADDR}_*.dat 2>/dev/null | wc -l)
	[ $NUM_IPADDR -lt ${!SNODES} ]
do  # do-while syntax sugar for bash
	sleep 3; echo -n .;
done
cat ${TMP_IPADDR}_*.dat >> $TMP_IPADDR && rm -f ${TMP_IPADDR}_*.dat;


####  RUN DISTRIBUTED MODES  ##################################################

set -e;
BATCH_JOBID=$(squeue -u `whoami` -n $JNAME -o "%i" | tail -n 1);
HOSTS=$(head -c $((`wc -c $TMP_IPADDR | cut -d' ' -f 1`-1)) $TMP_IPADDR);
echo "Running distributed modes in the slaves of the SLURM batch $BATCH_JOBID";
echo "Host IP addresses: $HOSTS";
echo "modes invocation arguments: ${ALLARGS[*]}";
time runmodes ${ALLARGS[*]} --hosts $HOSTS;


####  CLEAN-UP  ###############################################################

set +e;
scancel $BATCH_JOBID;
rm -f $TMP_SERVER $TMP_IPADDR $FRESH_FILE;
unset -f runmodes;
unset -v HOSTS BATCH_JOBID TMP_IPADDR TMP_SERVER FOUT_SERVERS \
	JNAME FRESHID FRESH_FILE MODES MONO \
	$STIME $SCORES $SNODES $SPART \
	STIME SCORES SNODES SPART \
	PTIME PCORES PNODES PPART \
	ALLARGS;
sleep 1;

exit 0

