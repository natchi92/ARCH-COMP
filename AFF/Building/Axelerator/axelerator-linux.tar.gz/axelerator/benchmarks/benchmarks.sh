../aa/axelerator -all 256 -u -ii convoyCar2.txt
../aa/axelerator -all 256 -u convoyCar3.txt
../aa/axelerator -all 256 -u parabola.txt
../aa/axelerator -all 256 -u cubic.txt
../aa/axelerator -all 256 -u inv_pendulum.txt
../aa/axelerator -all 256 -u oscilator.txt
../aa/axelerator -mp  1024 -u convoyCar2.txt
../aa/axelerator -mpi 1024 -u convoyCar2.txt
../aa/axelerator -mp  1024 -u convoyCar3.txt
../aa/axelerator -mpi 1024 -u convoyCar3.txt
../aa/axelerator -mp  1024 -u parabola.txt
../aa/axelerator -mpi 1024 -u parabola.txt
../aa/axelerator -mp  1024 -u cubic.txt
../aa/axelerator -mpi 1024 -u cubic.txt
../aa/axelerator -mp  1024 -u inv_pendulum.txt
../aa/axelerator -mpi 1024 -u inv_pendulum.txt
../aa/axelerator -mp  1024 -u oscilator.txt
../aa/axelerator -mpi 1024 -u oscilator.txt
