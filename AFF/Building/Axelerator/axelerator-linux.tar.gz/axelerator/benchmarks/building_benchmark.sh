../aa/axelerator -ld -params "p=48,v=1:1,l=2" -sguard "x25<.0051" -spaceex Building -inc cosine -sparse
../aa/axelerator -mpi 512 -params "p=48,v=1:1,l=2" -sguard "x25<.0051" -spaceex Building -inc cosine -sparse
